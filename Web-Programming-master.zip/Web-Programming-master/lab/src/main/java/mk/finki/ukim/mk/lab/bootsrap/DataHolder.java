package mk.finki.ukim.mk.lab.bootsrap;

import jakarta.annotation.PostConstruct;
import mk.finki.ukim.mk.lab.model.*;
import mk.finki.ukim.mk.lab.repository.jpa.CategoryRepository;
import mk.finki.ukim.mk.lab.repository.jpa.EventRepository;
import mk.finki.ukim.mk.lab.repository.jpa.LocationRepository;
import mk.finki.ukim.mk.lab.repository.jpa.UserRepository;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataHolder {
    public static List<Event> events = null;
    public static List<EventBooking> MyBookings = null;
    public static List<Category> categories = null;
    public static List<Location> locations = null;
    public static List<User> users = null;

    private final CategoryRepository categoryRepository;
    private final UserRepository userRepository;
    private final LocationRepository locationRepository;
    private final EventRepository eventRepository;

    public DataHolder(CategoryRepository categoryRepository, UserRepository userRepository,
                      LocationRepository locationRepository, EventRepository eventRepository) {
        this.categoryRepository = categoryRepository;
        this.userRepository = userRepository;
        this.locationRepository = locationRepository;
        this.eventRepository = eventRepository;
    }

    @PostConstruct
    public void init() {
        // Categories
        categories = new ArrayList<>();
        if (this.categoryRepository.count() == 0) {
            categories.add(new Category("Education"));
            categories.add(new Category("Food"));
            categories.add(new Category("Travel"));
            categories.add(new Category("Gaming"));
            categories.add(new Category("Nature"));
            categories.add(new Category("Fashion"));
            this.categoryRepository.saveAll(categories);
        }

        // Locations
        locations = new ArrayList<>();
        if (this.locationRepository.count() == 0) {
            locations.add(new Location("Harvard Campus", "Cambridge, MA, USA", "30,000", "Famous university campus."));
            locations.add(new Location("Bora Bora Island", "French Polynesia", "5,000", "Tropical paradise island."));
            locations.add(new Location("Gaming Arena", "Seoul, South Korea", "20,000", "Popular esports venue."));
            locations.add(new Location("Green Valley Park", "Wellington, New Zealand", "10,000", "Beautiful outdoor park."));
            locations.add(new Location("Fashion District", "Milan, Italy", "15,000", "Renowned fashion hub."));
            this.locationRepository.saveAll(locations);
        }

        // Events
        events = new ArrayList<>();
        if (this.eventRepository.count() == 0) {
            events.add(new Event("AI in Education", "Educational seminar on AI", 10, categories.get(0), locations.get(0), 100));
            events.add(new Event("Culinary Expo", "Food festival with famous chefs", 9, categories.get(1), locations.get(1), 120));
            events.add(new Event("Adventure Travel Fair", "Travel exhibition", 8, categories.get(2), locations.get(1), 80));
            events.add(new Event("Esports Championship", "Gaming competition", 10, categories.get(3), locations.get(2), 150));
            events.add(new Event("EcoTour", "Nature exploration", 7, categories.get(4), locations.get(3), 60));
            this.eventRepository.saveAll(events);
        }

        // Users
        users = new ArrayList<>();
        if (this.userRepository.count() == 0) {
            users.add(new User("dean.winchester", "password123", "Dean", "Winchester"));
            users.add(new User("stiles.smith", "securepass", "Stiles", "Smith"));
            users.add(new User("joy.taylor", "qwerty", "Joy", "Taylor"));
            this.userRepository.saveAll(users);
        }
    }
}
